package com.foap21.ej1layouts;

public class Persona {

    String nombre;
    int edad;
    boolean seleccionado;

    public Persona(String nombre, int edad, boolean seleccionado) {
        this.nombre = nombre;
        this.edad = edad;
        this.seleccionado = seleccionado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public boolean isSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(boolean seleccionado) {
        this.seleccionado = seleccionado;
    }
}
