package com.foap21.ej1layouts;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText et_nombre; //declaración de un EditText
    TextView tv_resultado;
    EditText et_edad;
    CheckBox checkBox;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //Layout que utiliza la activity

        //Asignarle el elemento del layout
        //El id "etName" corresponde al atributo id en el EditText del layout.
        et_nombre = findViewById(R.id.etName);
        tv_resultado = findViewById(R.id.tvResultado);
        et_edad = findViewById(R.id.etEdad);
        checkBox = findViewById(R.id.checkBox);
    }


    public void aceptarClicked(View view) {
        //Recoger el contenido del edittext getText().toString();
        //La variable resultado (de tipo String/texto) contiene ese texto
        String resultado = et_nombre.getText().toString();

        //Mostrar el resultado en un Toast (aparece en la parte inferior de la pantalla
        //durante unos segundos)
        //getString: función de Android para recoger un texto del fichero strings.xml
        //El parametro corresponde a la etiqueta del texto en el fichero.
        String texto_hola = getString(R.string.txthola);
        //Replace modifica el texto NOMBRE por el que se ha escrito en el EditText
        texto_hola = texto_hola.replace("NOMBRE", resultado);

        tv_resultado.setText(texto_hola); //Mostrar el contenido del EditText en el TextView inferior.

        //Integer.parseInt para transformar el String en número:
        int edad = Integer.parseInt(et_edad.getText().toString());
        boolean resultado_checkbox = checkBox.isChecked(); //Devuelve true si el checkbox esta seleccionado

        //Crear objeto de tipo Persona con los datos que ha añadido el usuario en la pantalla:
        Persona p = new Persona(resultado, edad, resultado_checkbox);
        Toast.makeText(this, "Usuario creado", Toast.LENGTH_LONG).show();

    }


    public void cancelClicked(View view) {
    //Llama a la función que crea y muestra el AlertDialog en pantalla.
        openDialog();
    }

    public void openDialog()
    {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle(getString(R.string.app_name)); //Modificar el titulo (nombre aplicación)
        alertDialogBuilder.setMessage(getString(R.string.alertMessage)) //Mensaje del alert
                .setCancelable(false) //Si permite o no que el usuari cierre el Dialog clicando fuera de él
                .setPositiveButton(getString(R.string.btnYes), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Si el usuario pulsa SI: Borrar contenido edittext, textview y checkbox
                        //Usamos "" para dejar el texto vacio tanto en el EditText como en el TextView:
                        et_nombre.setText("");
                        tv_resultado.setText("");
                        et_edad.setText("");
                        checkBox.setChecked(false); //Desseleccionar
                    }
                })
                .setNegativeButton(getString(R.string.btnNo), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Si el usuario pulsa NO: Cerrar el dialog sin hacer nada.
                        dialogInterface.cancel();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

    }
}