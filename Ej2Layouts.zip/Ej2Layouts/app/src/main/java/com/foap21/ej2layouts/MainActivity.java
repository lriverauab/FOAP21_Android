package com.foap21.ej2layouts;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etName, etPass, etMail, etPhone; //declaración EditTexts de la pantalla

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //asignar, con findViewById, los editext del layout a las variables
        //que hemos declarado arriba.
        //Importante: asignarle un ID a los EditText del layout.
        etName = findViewById(R.id.etName);
        etMail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etPass = findViewById(R.id.etPassword);

    }


    public void aceptarClicked(View view) {

        //recogiendo los textos que ha escrito el usuario en las cajas de texto
        //de la pantalla despues de clicar el botón Aceptar:

        String name = etName.getText().toString();
        String mail = etMail.getText().toString();
        String phone = etPhone.getText().toString();
        String pass = etPass.getText().toString();

        //Crear objeto de tipo Persona (nuestra clase).
        Persona persona = new Persona(name, mail, phone, pass);
        //Mostrar Toast (mensaje en la parte inferior pantalla).
        Toast.makeText(this, getString(R.string.personacreada), Toast.LENGTH_LONG).show();

        deleteContenido();
    }
    public void cancelClicked(View view) {
        openDialog(); //Llama a la función que abre el Alert.
    }

    public void deleteContenido() {
        etName.setText(""); //Deja en blanco el contenido del EditText
        etMail.setText("");
        etPhone.setText("");
        etPass.setText("");
    }

    public void openDialog() {
        //El builder crea el dialog (titulo, mensaje y que hacer cuando contesta si o no)
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);
        alertDialogBuilder.setTitle(getString(R.string.app_name)); //modificar el titol
        alertDialogBuilder.setMessage(getString(R.string.deleteMessage))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.btn_yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //Que haremos si clica que SI:
                        deleteContenido();
                    }
                })
                .setNegativeButton(getString(R.string.btn_no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel(); // No fem res, tanquem el Alert.
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create(); //crear el alert dialog
        alertDialog.show(); //mostrar per pantalla
    }
}